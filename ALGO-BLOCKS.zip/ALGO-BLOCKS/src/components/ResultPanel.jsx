import React from "react";

export default function ResultPanel({ result }) {
  if (!result) return null;

  if (result.error) {
    return (
      <div style={{
        color: "#e74c3c",
        fontWeight: 600,
        fontSize: "1.1rem",
        padding: "12px 0"
      }}>
        {result.error}
      </div>
    );
  }
  return (
    <div>
      <h3 style={{
        color: "#24344d",
        fontWeight: 700,
        marginBottom: "18px",
        fontSize: "1.25rem"
      }}>
        📊 Backtest Results
      </h3>
      <div style={{
        display: "flex",
        gap: "40px",
        flexWrap: "wrap",
        marginBottom: "18px"
      }}>
        <div>
          <div style={metricLabel}>Profit</div>
          <div style={metricValue}>₹{result.profit ?? "--"}</div>
        </div>
        <div>
          <div style={metricLabel}>Win Rate</div>
          <div style={metricValue}>{result.win_rate ? `${result.win_rate}%` : "--"}</div>
        </div>
        <div>
          <div style={metricLabel}>Max Drawdown</div>
          <div style={metricValue}>{result.max_drawdown ?? "--"}</div>
        </div>
        <div>
          <div style={metricLabel}>Sharpe Ratio</div>
          <div style={metricValue}>{result.sharpe_ratio ?? "--"}</div>
        </div>
      </div>
      {result.trades && result.trades.length > 0 && (
        <>
          <div style={{
            fontWeight: 600,
            color: "#3498db",
            marginBottom: "8px"
          }}>Recent Trades</div>
          <ul style={{
            listStyle: "none",
            padding: 0,
            margin: 0,
            maxHeight: "120px",
            overflowY: "auto"
          }}>
            {result.trades.map((trade, idx) => (
              <li key={idx} style={{
                color: trade.type === "buy" ? "#2ecc71" : "#e74c3c",
                fontWeight: 500,
                marginBottom: "4px"
              }}>
                {trade.date ? `${trade.date.slice(0, 10)} - ` : ""}
                {trade.type?.toUpperCase()} @ ₹{trade.price}
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

const metricLabel = {
  color: "#7b8898",
  fontWeight: 600,
  fontSize: "0.98rem",
  marginBottom: "2px"
};

const metricValue = {
  color: "#24344d",
  fontWeight: 700,
  fontSize: "1.18rem"
};
