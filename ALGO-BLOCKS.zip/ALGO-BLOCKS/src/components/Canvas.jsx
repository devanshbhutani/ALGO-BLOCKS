import React, { useRef, useCallback } from "react";
import ReactFlow, {
  ReactFlowProvider,
  addEdge,
  useNodesState,
  useEdgesState,
  Controls,
  Background,
  useReactFlow,
  MiniMap,
  Handle
} from "reactflow";
import "reactflow/dist/style.css";


let id = 0;
const getId = () => `node_${id++}`;

const getNodeColor = (label) => {
  switch (label) {
    case "Buy": return "#e6ffea";
    case "Sell": return "#ffebeb";
    case "MA": return "#e6f2ff";
    case "RSI": return "#fffde6";
    case "Stop Loss": return "#fff1e6";
    default: return "#ffffff";
  }
};

const getNodeBorderColor = (label) => {
  switch (label) {
    case "Buy": return "#2ecc71";
    case "Sell": return "#e74c3c";
    case "MA": return "#3498db";
    case "RSI": return "#f1c40f";
    case "Stop Loss": return "#e67e22";
    default: return "#95a5a6";
  }
};

const inputStyle = {
  width: "80px",
  padding: "6px",
  marginTop: "8px",
  border: "1px solid #ddd",
  borderRadius: "4px",
  backgroundColor: "#fff",
  color: "#222",
  textAlign: "center"
};

// Custom node renderer
const CustomNode = ({ data }) => (
  <div style={{
    background: getNodeColor(data.label),
    border: `2px solid ${getNodeBorderColor(data.label)}`,
    borderRadius: "8px",
    padding: "16px",
    minWidth: "150px",
    boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  }}>
    <div style={{ fontWeight: 600, marginBottom: "8px", color: "#222" }}>
      {data.label}
    </div>
    
    {data.label === "RSI" && (
      <input
        type="number"
        min="2"
        max="50"
        defaultValue={data.params?.period || 14}
        onChange={(e) => data.params.period = Number(e.target.value)}
        placeholder="Period"
        style={inputStyle}
        className="nodrag"
      />
    )}
    
    {data.label === "Stop Loss" && (
      <input
        type="number"
        min="1"
        max="20"
        defaultValue={data.params?.percent || 5}
        onChange={(e) => data.params.percent = Number(e.target.value)}
        placeholder="%"
        style={inputStyle}
        className="nodrag"
      />
    )}
    
    <Handle type="target" position="top" />
    <Handle type="source" position="bottom" />
  </div>
);

const nodeTypes = {
  custom: CustomNode
};

function FlowCanvas({ onExport, onBacktest }) {
  const reactFlowWrapper = useRef(null);
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const { project } = useReactFlow();

  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();
      const type = event.dataTransfer.getData("application/reactflow");
      if (!type) return;

      const bounds = reactFlowWrapper.current.getBoundingClientRect();
      const position = project({
        x: event.clientX - bounds.left,
        y: event.clientY - bounds.top,
      });

      const newNode = {
        id: getId(),
        type: "custom",
        position,
        data: { 
          label: type,
          params: {}
        },
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [project, setNodes]
  );

  return (
    <div
      ref={reactFlowWrapper}
      style={{
        position: "relative",
        flex: 1,
        height: "100%",
        backgroundColor: "#f5f6fa",
        boxSizing: "border-box",
      }}
    >
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onDrop={onDrop}
        onDragOver={onDragOver}
        nodeTypes={nodeTypes}
        fitView
        style={{ background: "#f5f6fa" }}
      >
        <MiniMap />
        <Controls />
        <Background />
      </ReactFlow>

      <div
        style={{
          position: "absolute",
          bottom: 32,
          right: 40,
          display: "flex",
          gap: "16px",
          zIndex: 100,
        }}
      >
        <button
          onClick={() => onExport(nodes, edges)}
          style={{
            padding: "12px 22px",
            backgroundColor: "#3498db",
            color: "#fff",
            border: "none",
            borderRadius: "7px",
            fontWeight: 600,
            fontSize: "1rem",
            cursor: "pointer",
            boxShadow: "0 2px 8px rgba(36,52,77,0.10)",
          }}
        >
          Export Strategy
        </button>
        <button
          onClick={() => onBacktest(nodes, edges)}
          style={{
            padding: "12px 22px",
            backgroundColor: "#00b894",
            color: "#fff",
            border: "none",
            borderRadius: "7px",
            fontWeight: 600,
            fontSize: "1rem",
            cursor: "pointer",
            boxShadow: "0 2px 8px rgba(36,52,77,0.10)",
          }}
        >
          Run Backtest
        </button>
      </div>
    </div>
  );
}

export default function Canvas({ onExport, onBacktest }) {
  return (
    <ReactFlowProvider>
      <FlowCanvas onExport={onExport} onBacktest={onBacktest} />
    </ReactFlowProvider>
  );
}
