import React from "react";
import { Tooltip } from "react-tooltip";

const blockList = [
  { label: "Buy", icon: "🟢", color: "#2ecc71", border: "#2ecc71", tooltip: "Buy order block" },
  { label: "Sell", icon: "🔴", color: "#e74c3c", border: "#e74c3c", tooltip: "Sell order block" },
  { label: "MA", icon: "📈", color: "#3498db", border: "#3498db", tooltip: "Moving Average indicator" },
  { label: "RSI", icon: "📊", color: "#f1c40f", border: "#f1c40f", tooltip: "Relative Strength Index indicator" },
  { label: "Stop Loss", icon: "⛔", color: "#e67e22", border: "#e67e22", tooltip: "Sell if price drops by a set %" }
];

const blockStyle = (color, border) => ({
  background: "#fff",
  borderRadius: "10px",
  boxShadow: "0 2px 8px rgba(36,52,77,0.06)",
  padding: "14px 22px",
  display: "flex",
  alignItems: "center",
  gap: "14px",
  cursor: "grab",
  border: `2px solid ${border}`,
  fontWeight: 500,
  color: "#24344d",
  fontSize: "1.1rem",
  marginBottom: "12px",
  transition: "box-shadow 0.2s",
  userSelect: "none",
  pointerEvents: "auto"
});

export default function Sidebar() {
  return (
    <div
      style={{
        width: "240px",
        background: "#f5f6fa",
        padding: "32px 18px 0 18px",
        borderRight: "1px solid #ececec",
        minHeight: "100vh"
      }}
    >
      <h4
        style={{
          color: "#b0b7c3",
          fontWeight: 700,
          letterSpacing: "1px",
          marginBottom: "28px",
          fontSize: "1.1rem",
          display: "flex",
          alignItems: "center",
          gap: "8px"
        }}
      >
        <span role="img" aria-label="blocks">📦</span> Trading Blocks
      </h4>
      <div style={{ display: "flex", flexDirection: "column" }}>
        {blockList.map((block) => (
          <div
            key={block.label}
            draggable
            onDragStart={e =>
              e.dataTransfer.setData("application/reactflow", block.label)
            }
            style={blockStyle(block.color, block.border)}
            data-tooltip-id="block-tooltip"
            data-tooltip-content={block.tooltip}
          >
            <span>{block.icon}</span>
            {block.label}
          </div>
        ))}
        <Tooltip
          id="block-tooltip"
          place="right"
          effect="solid"
          style={{
            zIndex: 1000,
            fontSize: "1rem",
            background: "#24344d",
            color: "#fff",
            borderRadius: "7px",
            padding: "8px 14px"
          }}
        />
      </div>
    </div>
  );
}
