// Header.jsx
import React from "react";

export default function Header({ activeTab, setActiveTab }) {
  return (
    <div
      style={{
        height: "64px",
        background: "#24344d",
        color: "#fff",
        display: "flex",
        alignItems: "center",
        padding: "0 36px",
        fontWeight: 700,
        fontSize: "2rem",
        letterSpacing: "1px",
        boxShadow: "0 2px 8px rgba(36,52,77,0.06)"
      }}
    >
      <span style={{ fontSize: "2.2rem", marginRight: "18px" }}>🧩</span>
      AlgoBlocks
      <div style={{ marginLeft: "auto", display: "flex", gap: "36px" }}>
        <button
          onClick={() => setActiveTab("results")}
          style={{
            background: "none",
            border: "none",
            color: activeTab === "results" ? "#fff" : "#cfd8dc",
            fontSize: "1.1rem",
            padding: "8px 0",
            cursor: "pointer",
            borderBottom: activeTab === "results" ? "3px solid #00b894" : "none"
          }}
        >
          Results
        </button>
        <button
          onClick={() => setActiveTab("docs")}
          style={{
            background: "none",
            border: "none",
            color: activeTab === "docs" ? "#fff" : "#cfd8dc",
            fontSize: "1.1rem",
            padding: "8px 0",
            cursor: "pointer",
            borderBottom: activeTab === "docs" ? "3px solid #00b894" : "none"
          }}
        >
          Docs
        </button>
      </div>
    </div>
  );
}
