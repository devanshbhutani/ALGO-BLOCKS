import React, { useState } from "react";
import Canvas from "./components/canvas";
import ResultPanel from "./components/resultpanel";
import Sidebar from "./components/sidebar";

export default function App() {
  const [results, setResults] = useState(null);
  const [activeTab, setActiveTab] = useState('results');

  const handleExport = (nodes, edges) => {
    const strategy = { nodes, edges };
    const blob = new Blob([JSON.stringify(strategy, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `algoblocks-strategy-${Date.now()}.json`;
    a.click();
  };

  const handleBacktest = async (nodes, edges) => {
    if (nodes.length === 0) {
      setResults({ error: "Please add at least one block to your strategy." });
      return;
    }
    if (
      !nodes.some(n => n.data.label === "Buy") ||
      !nodes.some(n => n.data.label === "Sell")
    ) {
      setResults({ error: "Strategy must include at least one Buy and one Sell block." });
      return;
    }

    try {
      const res = await fetch('http://localhost:8000/backtest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nodes: nodes.map(n => ({
            type: n.data.label,
            params: n.data.params
          })),
          edges
        })
      });
      const data = await res.json();
      setResults(data);
      setActiveTab('results');
    } catch {
      setResults({ error: 'Failed to connect to backtesting server' });
    }
  };

  return (
    <div style={{
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      background: '#f5f6fa'
    }}>
      <div style={headerStyle}>
        <div style={logoStyle}>
          <img
            src="/puzzle-piece.png"
            alt="AlgoBlocks Logo"
            style={{ width: "40px", height: "40px", marginRight: "16px" }}
            onError={(e) => {
              e.target.onerror = null;
              e.target.style.display = 'none';
              e.target.parentElement.prepend('🧩');
            }}
          />
          <h1 style={{ margin: 0, fontSize: '2.2rem', letterSpacing: '1px' }}>AlgoBlocks</h1>
        </div>
        <nav style={navStyle}>
          <button
            onClick={() => setActiveTab('results')}
            style={activeTab === 'results' ? activeTabStyle : tabStyle}
          >
            Results
          </button>
          <button
            onClick={() => setActiveTab('docs')}
            style={activeTab === 'docs' ? activeTabStyle : tabStyle}
          >
            Docs
          </button>
        </nav>
      </div>

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <Sidebar />
        <Canvas onExport={handleExport} onBacktest={handleBacktest} />
      </div>
      {activeTab === "results" && results && (
        <div style={resultsPanelStyle}>
          <button
            onClick={() => setResults(null)}
            style={{
              position: "absolute",
              top: 10,
              right: 20,
              background: "none",
              border: "none",
              fontSize: "1.5rem",
              color: "#888",
              cursor: "pointer",
              zIndex: 10
            }}
            aria-label="Close results"
            title="Close results"
          >
            ×
          </button>
          <ResultPanel result={results} />
        </div>
      )}
      {activeTab === "docs" && (
        <div style={docsPanelStyle}>
          <button
            onClick={() => setActiveTab('results')}
            style={{
              position: "absolute",
              top: 10,
              right: 20,
              background: "none",
              border: "none",
              fontSize: "1.5rem",
              color: "#888",
              cursor: "pointer",
              zIndex: 10
            }}
            aria-label="Close docs"
            title="Close docs"
          >
            ×
          </button>
          <h2 style={{ marginTop: 0, color: "#24344d", fontWeight: 700 }}>
            📖 AlgoBlocks Documentation
          </h2>
          <ul style={{ color: "#24344d", fontSize: "1.08rem", lineHeight: 1.7 }}>
            <li><b>Buy:</b> Executes a buy order when triggered.</li>
            <li><b>Sell:</b> Executes a sell order when triggered.</li>
            <li><b>MA:</b> Moving Average indicator, e.g., MA50.</li>
            <li><b>RSI:</b> Relative Strength Index, a momentum indicator (default 14).</li>
            <li><b>Stop Loss:</b> Sells automatically if price drops by a set % after buying.</li>
          </ul>
          <p style={{ color: "#24344d", fontSize: "1.07rem" }}>
            Connect blocks to build your strategy visually, then run a backtest to see results!
          </p>
        </div>
      )}
    </div>
  );
}

// Style constants
const headerStyle = {
  background: '#24344d',
  color: 'white',
  padding: '12px 30px',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
};

const logoStyle = {
  display: 'flex',
  alignItems: 'center',
  fontWeight: 700,
  fontSize: '1.2rem'
};

const navStyle = {
  display: 'flex',
  gap: '24px'
};

const tabStyle = {
  padding: '8px 16px',
  background: 'none',
  border: 'none',
  color: '#cfd8dc',
  cursor: 'pointer',
  fontSize: '1.1rem',
  fontWeight: 500,
  transition: 'all 0.2s ease'
};

const activeTabStyle = {
  ...tabStyle,
  color: 'white',
  borderBottom: '3px solid #3498db'
};

const resultsPanelStyle = {
  background: 'white',
  padding: '20px 32px',
  borderTop: '2px solid #ecf0f1',
  maxHeight: '30vh',
  overflowY: 'auto',
  boxShadow: '0 -2px 10px rgba(0,0,0,0.05)',
  position: 'relative'
};

const docsPanelStyle = {
  background: "#fff",
  padding: "32px",
  maxWidth: "700px",
  margin: "32px auto",
  borderRadius: "10px",
  boxShadow: "0 2px 12px rgba(36,52,77,0.08)",
  color: "#24344d",
  fontSize: "1.1rem",
  position: "relative"
};
