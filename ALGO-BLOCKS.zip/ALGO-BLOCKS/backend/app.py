from flask import Flask, jsonify, request
from flask_cors import CORS
from backtest import Backtester

app = Flask(__name__)
CORS(app)
backtester = Backtester("NSEI_Historical_Data.csv")

@app.route("/api/data", methods=["GET"])
def get_data():
    df = backtester.data.head(10)
    return jsonify(df.to_dict(orient="records"))

@app.route("/backtest", methods=["POST"])
def handle_backtest():
    strategy = request.json
    results = backtester.run_backtest(strategy)
    
    # Ensure we have all required fields for the frontend
    if "trade_history" in results and not "trades" in results:
        results["trades"] = len(results["trade_history"])
    
    return jsonify(results)

if __name__ == "__main__":
    app.run(debug=True, port=8000)
